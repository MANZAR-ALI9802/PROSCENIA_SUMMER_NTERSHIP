// Runs when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('greetBtn');
  const nameInput = document.getElementById('nameInput');
  const output = document.getElementById('output');

  button.addEventListener('click', () => {
    const name = nameInput.value.trim();

    if (name) {
      output.textContent = `Hello, ${name}! 👋`;
    } else {
      output.textContent = "Please enter your name.";
    }
  });
});
