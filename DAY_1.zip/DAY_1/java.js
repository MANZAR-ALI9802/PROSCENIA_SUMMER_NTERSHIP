function greetUser() {
  const name = document.getElementById("name-input").value.trim();
  const greeting = document.getElementById("greeting-select").value;
  const output = document.getElementById("output");

  if (name === "" || greeting === "") {
    output.innerHTML = "⚠️ Please enter your name and select a greeting.";
    return;
  }

  output.innerHTML = `${greeting}, ${name}! 👋`;
}

// onchange inline function in HTML
function handleChange() {
  const selected = document.getElementById("greeting-select").value;
  console.log("Greeting selected:", selected);
}

// addEventListener example
const resetBtn = document.getElementById("reset-btn");

resetBtn.addEventListener("click", function () {
  document.getElementById("name-input").value = "";
  document.getElementById("greeting-select").value = "";
  document.getElementById("output").innerHTML = "";
});
