// Define student object
const student = {
  name: "Manzar Ali",
  roll: 123,
  marks: {
    math: 88,
    physics: 92,
    english: 79
  },

  // Method to calculate average marks
  getAverage: function () {
    const total = this.marks.math + this.marks.physics + this.marks.english;
    return (total / 3).toFixed(2);
  },

  // Method to generate student report
  getReport: function () {
    return `
Name     : ${this.name}
Roll No. : ${this.roll}

Marks:
  Math     : ${this.marks.math}
  Physics  : ${this.marks.physics}
  English  : ${this.marks.english}

Average Marks: ${this.getAverage()}
    `;
  }
};

// DOM interaction using addEventListener
document.getElementById("show-report-btn").addEventListener("click", function () {
  const reportText = student.getReport();
  document.getElementById("report-output").innerText = reportText;
});
