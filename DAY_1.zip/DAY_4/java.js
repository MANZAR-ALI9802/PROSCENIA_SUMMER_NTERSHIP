// Get DOM elements
const taskInput = document.getElementById('task-input');
const addTaskBtn = document.getElementById('add-task-btn');
const taskList = document.getElementById('task-list');

// Load tasks from LocalStorage
function loadTasks() {
  const storedTasks = localStorage.getItem('tasks');
  if (storedTasks) {
    const tasks = JSON.parse(storedTasks); // Convert JSON string to object
    tasks.forEach(task => {
      createTaskElement(task);
    });
  }
}

// Save tasks to LocalStorage
function saveTasks() {
  const taskElements = document.querySelectorAll('.task');
  const tasks = [];
  taskElements.forEach(taskElement => {
    tasks.push({
      text: taskElement.querySelector('.task-text').innerText,
    });
  });
  localStorage.setItem('tasks', JSON.stringify(tasks)); // Convert object to JSON string
}

// Create a new task element
function createTaskElement(task) {
  const li = document.createElement('li');
  li.classList.add('task');
  
  li.innerHTML = `
    <span class="task-text">${task.text}</span>
    <button class="delete-btn">Delete</button>
  `;
  
  // Add event listener to delete button
  li.querySelector('.delete-btn').addEventListener('click', function () {
    li.remove();
    saveTasks(); // Update LocalStorage after deletion
  });

  taskList.appendChild(li);
}

// Add new task
addTaskBtn.addEventListener('click', function () {
  const taskText = taskInput.value.trim();
  if (taskText === '') {
    return;
  }
  
  const task = { text: taskText };
  createTaskElement(task); // Create task element
  taskInput.value = ''; // Clear input field
  saveTasks(); // Save task to LocalStorage
});

// Load tasks from LocalStorage when the page loads
window.onload = loadTasks;
