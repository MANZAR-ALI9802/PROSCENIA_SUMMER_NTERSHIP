// Destructuring the student object
const student = {
  name: "John Doe",
  age: 22,
  scores: { math: 95, english: 88, science: 92 }
};

// Using destructuring to extract properties
const { name, age, scores: { math, english, science } } = student;

// Using template literals to generate a report
const report = `
  Student: ${name}
  Age: ${age}
  Math Score: ${math}
  English Score: ${english}
  Science Score: ${science}

  Overall Average: ${(math + english + science) / 3}
`;

document.getElementById("report").innerText = report;

// Spread Operator Example: Combining two objects
const studentInfo = { name, age };
const studentGrades = { math, english, science };

const fullReport = { ...studentInfo, ...studentGrades };
console.log(fullReport);

// Rest Operator Example: Collecting remaining properties
const { math: mathScore, ...rest } = student.scores;
console.log(mathScore); // 95
console.log(rest); // { english: 88, science: 92 }
