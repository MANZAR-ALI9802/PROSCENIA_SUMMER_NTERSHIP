// Quiz data (questions, options, correct answer)
const questions = [
  {
    "question": "What is the capital of France?",
    "options": ["Paris", "London", "Berlin", "Madrid"],
    "answer": "Paris"
  },
  {
    "question": "What is 2 + 2?",
    "options": ["3", "4", "5", "6"],
    "answer": "4"
  },
  {
    "question": "Which planet is known as the Red Planet?",
    "options": ["Earth", "Mars", "Venus", "Jupiter"],
    "answer": "Mars"
  }
];

let currentQuestionIndex = 0;
let score = 0;

// Function to load the current question and options
function loadQuestion() {
  const question = questions[currentQuestionIndex];
  const questionContainer = document.getElementById('question-container');

  // Generate HTML for question and options
  const options = question.options.map((option) => {
    return `
      <label>
        <input type="radio" name="option" value="${option}" /> ${option}
      </label><br/>
    `;
  }).join('');

  questionContainer.innerHTML = `
    <h2>${question.question}</h2>
    ${options}
  `;
}

// Function to handle the "Next Question" click
document.getElementById('next-button').addEventListener('click', function() {
  const selectedOption = document.querySelector('input[name="option"]:checked');
  
  if (selectedOption) {
    const answer = selectedOption.value;
    const correctAnswer = questions[currentQuestionIndex].answer;
    
    // Check if the answer is correct
    if (answer === correctAnswer) {
      score++;
    }

    // Store the score in localStorage
    localStorage.setItem('score', score);

    // Move to the next question
    currentQuestionIndex++;

    // If all questions are answered, show the score
    if (currentQuestionIndex < questions.length) {
      loadQuestion();
    } else {
      showScore();
    }
  } else {
    alert('Please select an option!');
  }
});

// Function to display the final score
function showScore() {
  const scoreContainer = document.getElementById('score-container');
  scoreContainer.innerHTML = `Your score is: ${score} / ${questions.length}`;
}

// Load the first question when the page loads
window.onload = loadQuestion;
