function showVariables() {
  var message = "Hello from var!";
  let age = 20;
  const country = "Pakistan";

  let isStudent = true;
  let scores = [85, 90, 95];
  let person = { name: "Manzar", enrolled: true };

  let output = `
    <strong>String:</strong> ${message}<br>
    <strong>Number:</strong> ${age}<br>
    <strong>Constant:</strong> ${country}<br>
    <strong>Boolean:</strong> ${isStudent}<br>
    <strong>Array:</strong> ${scores.join(", ")}<br>
    <strong>Object:</strong> ${JSON.stringify(person)}<br>
  `;

  document.getElementById("output").innerHTML = output;
}
