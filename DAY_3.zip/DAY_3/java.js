// Array of student objects
const students = [
  { name: "John", grade: 85 },
  { name: "Jane", grade: 92 },
  { name: "Tom", grade: 76 },
  { name: "Alice", grade: 89 },
  { name: "Bob", grade: 65 }
];

// map() - Get names of all students
const studentNames = students.map(student => student.name);

// filter() - Get students with grades >= 80
const passingStudents = students.filter(student => student.grade >= 80);

// reduce() - Calculate total grade
const totalGrade = students.reduce((acc, student) => acc + student.grade, 0);
const averageGrade = (totalGrade / students.length).toFixed(2);

function showReport() {
  const report = `
Student Names: ${studentNames.join(", ")}

Passing Students (Grade >= 80): ${passingStudents.map(s => s.name).join(", ")}

Average Grade: ${averageGrade}
  `;

  document.getElementById("output").innerText = report;
}
