// Using getElementById
const heading = document.getElementById("main-heading");

// Using querySelector
const paragraph = document.querySelector(".info-text");

// Using getElementById to get the button
const button = document.getElementById("change-btn");

// Add click event listener to button
button.addEventListener("click", function () {
  // Update heading using innerHTML
  heading.innerHTML = "You Clicked the Button!";

  // Update paragraph using innerHTML
  paragraph.innerHTML = "The text has been updated using JavaScript.";
});
