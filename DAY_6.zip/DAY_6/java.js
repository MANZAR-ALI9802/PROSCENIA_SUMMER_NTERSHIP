function startTask() {
  document.getElementById('output').innerText = "Starting task...";

  // Step 1: Using setTimeout to simulate delayed operation
  setTimeout(() => {
    document.getElementById('output').innerText = "Task completed after 2 seconds!";
  }, 2000);

  // Step 2: Using setInterval to repeatedly check task status
  const intervalId = setInterval(() => {
    document.getElementById('output').innerText += "\nChecking task status...";
  }, 1000);

  // Stop the interval after 5 seconds
  setTimeout(() => {
    clearInterval(intervalId);
    document.getElementById('output').innerText += "\nTask checking stopped.";
  }, 5000);

  // Step 3: Using Promise to simulate async task
  const taskPromise = new Promise((resolve, reject) => {
    const taskSuccess = true; // Change to false to simulate failure
    setTimeout(() => {
      if (taskSuccess) {
        resolve("Promise: Task was successful!");
      } else {
        reject("Promise: Task failed.");
      }
    }, 3000);
  });

  taskPromise
    .then(result => {
      document.getElementById('output').innerText += `\n${result}`;
    })
    .catch(error => {
      document.getElementById('output').innerText += `\n${error}`;
    });
}
