const taskInput = document.getElementById("task-input");
const addTaskBtn = document.getElementById("add-task-btn");
const taskList = document.getElementById("task-list");

addTaskBtn.addEventListener("click", function () {
  const taskText = taskInput.value.trim();

  if (taskText === "") {
    alert("Please enter a task.");
    return;
  }

  // Create <li> element
  const listItem = document.createElement("li");

  // Set task text
  listItem.innerHTML = `
    <span>${taskText}</span>
    <button class="delete-btn">X</button>
  `;

  // Add toggle complete on click
  listItem.querySelector("span").addEventListener("click", function () {
    this.classList.toggle("completed");
  });

  // Delete task on button click
  listItem.querySelector(".delete-btn").addEventListener("click", function () {
    taskList.removeChild(listItem);
  });

  // Add list item to task list
  taskList.appendChild(listItem);

  // Clear input
  taskInput.value = "";
});
