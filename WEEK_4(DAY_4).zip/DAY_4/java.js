let students = ["Ali", "Aisha", "Bilal", "Fatima", "Zain"];

function showStudents() {
  let list = document.getElementById("studentList");
  list.innerHTML = "";

  // Using for loop to display student names
  for (let i = 0; i < students.length; i++) {
    let li = document.createElement("li");
    li.innerText = students[i];
    list.appendChild(li);
  }

  // Example: while loop to print count in console
  let count = 0;
  while (count < students.length) {
    console.log("Student " + (count + 1) + ": " + students[count]);
    count++;
  }

  // Example: do-while loop
  let index = 0;
  do {
    console.log("Checking student at index: " + index);
    index++;
  } while (index < 2);
}
