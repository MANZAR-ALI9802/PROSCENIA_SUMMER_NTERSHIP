// Global variable
let globalVar = "🌍 Global Variable";

function runRegularFunction() {
    function regularFunction() {
        document.getElementById("output").innerHTML = "✅ Regular Function: 'this' is " + this;
    }
    regularFunction();
}

function runArrowFunction() {
    const arrowFunc = () => {
        document.getElementById("output").innerHTML = "✅ Arrow Function: 'this' is " + this;
    };
    arrowFunc();
}

function testScope() {
    let output = "";

    output += `🌍 Global Variable: ${globalVar}<br>`;

    function localFunction() {
        let localVar = "🔒 Local to Function";
        output += `🔹 Inside Function: ${localVar}<br>`;

        if (true) {
            let blockVar = "🧱 Block Scoped";
            output += `🔸 Inside Block: ${blockVar}<br>`;
        }

        // Trying to access blockVar outside the block would cause error
        // output += blockVar; // Uncommenting this line will throw error
    }

    localFunction();

    document.getElementById("output").innerHTML = output;
}
